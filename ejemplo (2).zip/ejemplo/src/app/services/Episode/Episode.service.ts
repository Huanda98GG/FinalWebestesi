import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EpisodeService {
  private apiUrl = 'https://rickandmortyapi.com/api';

  constructor(private http: HttpClient) {}

  // Obtener todos los episodios (paginados)
  getEpisodes(): Observable<any> {
    return this.http.get(`${this.apiUrl}/episode`);
  }

  // Obtener un episodio por ID
  getEpisodeById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/episode/${id}`);
  }

  // Obtener personajes desde un arreglo de URLs
  getCharactersByUrls(urls: string[]): Observable<any[]> {
    const requests = urls.map(url => this.http.get(url));
    return forkJoin(requests);
  }
}
