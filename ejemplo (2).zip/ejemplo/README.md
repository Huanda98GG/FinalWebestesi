npm install
npm install sweetalert2
ng serve

Back 
npm install express sequelize mysql2 cors body-parser helmet morgan dotenv 
npm install --save-dev nodemon sequelize-cli
npx sequelize-cli init
npm install jsonwebtoken bcryptjs express-jwt
npm i
npx sequelize-cli db:migrate
npm run dev


Cambios: 
auth.service
app.routes
ejemplo.services
pages
Modelo


