import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MaterialModule } from 'src/app/material.module';
import { Episode } from 'src/app/models/episode.model';
import { EpisodeService } from 'src/app/services/Episode/Episode.service';
import { AlertService } from 'src/app/services/alert/alert.service';

@Component({
  selector: 'app-episode-list',
  standalone: true,
  imports: [MaterialModule, CommonModule],
  templateUrl: './episode-list.component.html',
  styleUrl: './episode-list.component.scss'
})
export class EpisodeListComponent {
  episodeList: Episode[] = [];

  constructor(
    private pService: EpisodeService,
    private router: Router,
    private alertService: AlertService
  ) { }

  ngOnInit(id: number) {
    this.getEpisode(id);
  }

  goToEpisodeForm(id?: number) {
    if (id) {
      this.router.navigate(['episodes/episode/', id])
    }
  }
  goToSCreateForm() {
    this.router.navigate(['episodes/addEpisode'])
  }
  getEpisode(id: number) {
    this.pService.getEpisode(id).subscribe({
      next: (res) => {
        this.episodeList = res;
      },
      error: (err) => {
        if (err.status === 403) {
          localStorage.removeItem('AuthToken');
          this.router.navigate(['/login']);
        }
        this.alertService.ConfirmationAlert("Error", "Could not fetch episode data");
      }
    });
  }

  
}

