import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MaterialModule } from 'src/app/material.module';
import { Episode} from 'src/app/models/episode.model';   
import { EpisodeService } from 'src/app/services/Episode/Episode.service';
import { AlertService } from 'src/app/services/alert/alert.service';

@Component({
  selector: 'app-episode-form',
  imports: [MaterialModule, ReactiveFormsModule, CommonModule],
  templateUrl: './episode-form.component.html',
  styleUrl: './episode-form.component.scss'
})
export class EpisodeFormComponent {
  form!: FormGroup;
  editMode: boolean = false;
  episodeId: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: EpisodeService,
    private fb: FormBuilder,
    private alertService: AlertService
  ) { }

  initForm(): void {
    this.form = this.fb.group({
      name: ['', Validators.required],
      passportId: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      seatPreference: ['', Validators.required],
      mealPreference: ['', Validators.required],
      isActive: [true, [Validators.required]]
    });
  }

  

  getEpisodeById(id: number) {
    this.service.getEpisode(id).subscribe({
      next: (episode: Episode) => {
        this.form.patchValue({
          name: episode.name,
          passportId: episode.passportId,
          email: episode.email,
          phone: episode.phone,
          seatPreference: episode.seatPreference,
          mealPreference: episode.mealPreference,
          isActive: episode.isActive
        });
      },
      error: () => {
        console.error("Error fetching Episode data");
      }
    });
  }

  saveEpisodeInfo() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.alertService.ErrorAlert("Error", "Please fill all required fields");
      return;
    }

    const episodeData: Episode = this.form.value;
  }
}