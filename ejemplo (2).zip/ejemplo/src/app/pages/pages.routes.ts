import { Routes } from '@angular/router';
import { EpisodesComponent } from './starter/starter.component';
import { EpisodeListComponent } from './episode/episode-list/episode-list.component';

export const PagesRoutes: Routes = [
  {
    path: '',
    component: EpisodeListComponent,
    data: {
      title: 'Starter Page',
      urls: [
        { title: 'Dashboard', url: '/dashboards/dashboard1' },
        { title: 'Starter Page' },
      ],
    },
  },
];
