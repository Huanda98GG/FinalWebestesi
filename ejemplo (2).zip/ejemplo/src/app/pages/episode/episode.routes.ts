import { Routes } from '@angular/router';
import { EpisodeListComponent } from './episode-list/episode-list.component';
import { EpisodeFormComponent } from './episode-form/episode-form.component';
import { CreateepisodeFormComponent } from './createepisode-form/createepisode-form.component';
import { authGuard } from 'src/app/guards/auth.guard';
import { C } from '@angular/cdk/keycodes';



export const episodeRoutes: Routes = [{
    path: '',
    children: [
        {
            path: '',
            component: EpisodeListComponent
        },
         {
            path: 'episode/:id',
            component: EpisodeFormComponent
        },
        {
            path: 'addEpisode',
            component: CreateepisodeFormComponent
        }
    ], //canActivate: [authGuard]
}]

