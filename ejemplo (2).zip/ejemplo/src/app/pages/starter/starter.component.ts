import { Component, OnInit } from '@angular/core';

interface Episode {
  id: number;
  name: string;
  episode: string;
  air_date: string;
}

interface Character {
  id: number;
  name: string;
  status: string;
  species: string;
  image: string;
}

@Component({
  selector: 'app-episodes',
  templateUrl: './episode.component.html',
  styleUrls: ['./episode.component.css']
})
export class EpisodesComponent implements OnInit {
  episodes: Episode[] = [];
  selectedEpisode: Episode | null = null;
  characters: Character[] = [];

  constructor() {}

  ngOnInit(): void {
    
    this.episodes = [
      { id: 1, name: 'Pilot', episode: 'S01E01', air_date: 'December 2, 2013' },
      { id: 2, name: 'Lawnmower Dog', episode: 'S01E02', air_date: 'December 9, 2013' }
      
    ];
  }

  onSelectEpisode(ep: Episode): void {
    this.selectedEpisode = ep;

    
    this.characters = [
      {
        id: 1,
        name: 'Rick Sanchez',
        status: 'Alive',
        species: 'Human',
        image: 'https://rickandmortyapi.com/api/character/avatar/1.jpeg'
      },
      {
        id: 2,
        name: 'Morty Smith',
        status: 'Alive',
        species: 'Human',
        image: 'https://rickandmortyapi.com/api/character/avatar/2.jpeg'
      }
    ];
  }
}
