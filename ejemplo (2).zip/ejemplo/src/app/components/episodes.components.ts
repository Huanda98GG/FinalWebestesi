import { Component, OnInit } from '@angular/core';
import { EpisodeService } from './episode.service';

@Component({
  selector: 'app-episodes',
  templateUrl: './episodes.component.html',
  styleUrls: ['./episodes.component.css']
})
export class EpisodesComponent implements OnInit {
  episodes: any[] = [];
  selectedEpisode: any = null;
  characters: any[] = [];

  constructor(private episodeService: EpisodeService) {}

  ngOnInit(): void {
    this.episodeService.getEpisodes().subscribe(response => {
      this.episodes = response.results;
    });
  }

  onSelectEpisode(ep: any): void {
    this.episodeService.getEpisodeById(ep.id).subscribe(data => {
      this.selectedEpisode = data;
      this.loadCharacters(data.characters);
    });
  }

  loadCharacters(urls: string[]): void {
    this.episodeService.getCharactersByUrls(urls).subscribe(chars => {
      this.characters = chars;
    });
  }
}
